1. upload the orc and traning_type into Colab
2. run 'sorting_character.ipynb' to get training images
3. will get the images in each letter folders